package bgu.spl.mics;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.AfterAll;

import org.junit.jupiter.api.Test;

import java.util.concurrent.TimeUnit;


import static org.junit.jupiter.api.Assertions.*;


public class FutureTest {

    private Future<String> future;
    private String s;


    @BeforeEach
    public void setUp() {
        future = new Future<>();
        s = "Hi";
    }

    @Test
    public void testGet() {
        assertFalse(future.isDone()); //if is done- exception!
        future.resolve("");
        future.get(100, TimeUnit.MILLISECONDS);
        assertTrue(future.isDone());
    }

    @Test
    public void testResolve() {
        String str = "res";
        future.resolve(str);
        assertTrue(future.isDone());
        assertTrue(str.equals(future.get()));
    }

    @Test
    public void testIsDone() {
        String str = "res";
        assertFalse(future.isDone());
        future.resolve(str);
        assertTrue(future.isDone());
    }
    @Test
    public void testGetWithTimeOut() {
        assertFalse(future.isDone());
        future.get(10, TimeUnit.MILLISECONDS);
        assertFalse(future.isDone());
        future.resolve(s);
        assertEquals(future.get(10, TimeUnit.MILLISECONDS), s);
    }
}
