package bgu.spl.mics;

import bgu.spl.mics.application.messages.AttackEvent;
import bgu.spl.mics.application.messages.LandoFinished;
import bgu.spl.mics.application.passiveObjects.Attack;
import bgu.spl.mics.application.services.C3POMicroservice;
import bgu.spl.mics.application.services.LeiaMicroservice;
import bgu.spl.mics.application.services.R2D2Microservice;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.LinkedList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class MessageBusImplTest {

    private MessageBusImpl messageBus;
    private R2D2Microservice R2D2;
    private AttackEvent attackEvent;
    private Broadcast broadcast;
    private C3POMicroservice C3PO;


    @BeforeEach
    void setUp() {
        messageBus = MessageBusImpl.getInstance();
        R2D2 = new R2D2Microservice(3000);
        C3PO = new C3POMicroservice();
        attackEvent = new AttackEvent(5000, new LinkedList<>());
        broadcast = new LandoFinished() {
        };
    }

    @AfterEach
    void tearDown() {
        messageBus = null;
        R2D2 = null;
    }

    @Test
    void testSubscribeEvent() {
        //dont need to implement- the testSentEvent checks this function also
    }

    @Test
    void testSubscribeBroadcast() {
        //dont need to implement- the testSentBroadcast checks this function also
    }

    @Test
    void testComplete() {
        try{
        Event<Boolean> e = new AttackEvent(5000, new LinkedList<>());
        messageBus.subscribeEvent(AttackEvent.class, C3PO);
        boolean checked = true;
        Future<Boolean> futureCheck = C3PO.sendEvent(e);
        messageBus.complete(e, checked);
        assertTrue(futureCheck.isDone());
        assertEquals(true, futureCheck.get());
    } catch (NullPointerException e) {
        e.printStackTrace();
    }}

    @Test
    void testSendBroadcast() {
        try {
        R2D2Microservice a = new R2D2Microservice(3000);
        R2D2Microservice b = new R2D2Microservice(3000);
        R2D2Microservice c = new R2D2Microservice(3000);
        messageBus.subscribeBroadcast(broadcast.getClass(), a);
        messageBus.subscribeBroadcast(broadcast.getClass(), b);
        messageBus.subscribeBroadcast(broadcast.getClass(), c);
        R2D2.sendBroadcast(broadcast);
        Message a1 = null;
        Message b1 = null;
        Message c1 = null;

        a1 = messageBus.awaitMessage(a);
        b1 = messageBus.awaitMessage(b);
        c1 = messageBus.awaitMessage(c);
        assertEquals(a1, broadcast);
        assertEquals(b1, broadcast);
        assertEquals(c1, broadcast);

        } catch (NullPointerException  | InterruptedException ex) {
            ex.printStackTrace();
        }
    }

    @Test
        //checks the subscribe event also
    void testSendEvent() {
        try {
        R2D2Microservice c = new R2D2Microservice(3000);
        Event<Boolean> e = new AttackEvent(5000, new LinkedList<>());
        messageBus.subscribeEvent(attackEvent.getClass(), R2D2);
        Future<Boolean> check = c.sendEvent(e);
        Message m = null;
            assertTrue(check.isDone());
            assertEquals(e, m);
            m = messageBus.awaitMessage(R2D2);
        } catch (InterruptedException | NullPointerException d) {
            d.printStackTrace();
        }
    }

    @Test
        //assumes the queue is not empty
    void testAwaitMessage() {
        messageBus.subscribeBroadcast(LandoFinished.class, C3PO);
        messageBus.sendBroadcast(broadcast);
        try {
            Message message = messageBus.awaitMessage(C3PO);
            assertEquals(message, broadcast);
        } catch (NullPointerException | InterruptedException e) {
            e.printStackTrace();
        }

    }
}